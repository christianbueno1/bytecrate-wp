<?php
/**
 * Template part for displaying the fibo search modal
 *
 * @package Motta
 */
?>
<div id="fibo-search-modal" class="fibo-search-modal">
	<?php echo do_shortcode( \Motta\Helper::get_option('header_search_shortcode') ); ?>
</div>