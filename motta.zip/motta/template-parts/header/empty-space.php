<?php
/**
 * Template part for displaying the empty space
 *
 * @package Motta
 */

?>
<div class="header-empty-space"></div>