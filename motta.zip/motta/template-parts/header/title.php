<?php
/**
 * Template part for displaying the title
 *
 * @package Motta
 */
?>
<div class="header-post-title">
	<span class="product-title"><?php echo get_the_title(); ?></span>
	<span class="product-price"></span>
</div>