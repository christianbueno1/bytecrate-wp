<?php
/**
 * Template part for displaying the search items
 *
 * @package Motta
 */

?>

<div class="header-search__icon">
	<?php echo \Motta\Icon::get_svg( 'search' ); ?>
</div>